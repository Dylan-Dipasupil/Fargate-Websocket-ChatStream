// app.ts
import { App, LogLevel } from '@slack/bolt';
import { getSlackSecret } from '@src/helpers/slack/slack-helpers'
import { SlackEventsEnv } from '@functions/slack-event-handler';
import { makeLogger } from '@src/logging';
import { Secret } from '@src/helpers/slack/slack-helpers';
import { log } from 'console';


const logger = makeLogger('ws-app-handler');


let appInstance: App | null = null;
  
  export const createApp = async (env: SlackEventsEnv): Promise<App> => {
    if (appInstance === null) {
        logger.debug('Creating app from null')
        const secret = await getSlackSecret(env);
        logger.debug(`Secret: ${JSON.stringify(secret)}`)
        appInstance = new App({
            token: secret.SlackBotUserOAuthToken,
            signingSecret: secret.SlackSigningSecret,
            socketMode: true,
            appToken: secret.SlackAppToken,
            logLevel: LogLevel.DEBUG
      });
    }
    return appInstance;
  };
  
  export const getApp = async (env: SlackEventsEnv): Promise<App> => {
    if (appInstance === null) {
      appInstance = await createApp(env);
    }
    logger.debug('Getting app')
    return appInstance;
  };

//   export const streamResponseToClient = async (response: any, app: App, channelID: string, secret: Secret): Promise<void> => {
//     const chunks = splitIntoChunks(response, 10);
//     let currentText = chunks[0];
  
//     const initialMessage = await app.client.chat.postMessage({
//       token: secret.SlackBotUserOAuthToken,
//       text: currentText,
//       channel: channelID
//     });
  
//     let timestamp = initialMessage.message?.ts;
//     let newChannelId = initialMessage.channel;
  
//     if (newChannelId === undefined) {
//       throw new Error('Channel ID is undefined');
//     }
  
//     if (timestamp === undefined) {
//       throw new Error('Timestamp is undefined');
//     }
  
//     for (let i = 1; i < chunks.length; i++) {
//       currentText += chunks[i];
//       let updated_message = await app.client.chat.update({
//         token: secret.SlackBotUserOAuthToken,
//         text: currentText,
//         channel: newChannelId,
//         ts: timestamp
//       });
  
//       if (updated_message.ts && updated_message.channel) {
//         timestamp = updated_message.ts;
//         newChannelId = updated_message.channel;
//       } else {
//         timestamp = initialMessage.message?.ts!;
//         newChannelId = initialMessage.channel!;
//         throw new Error('Updated_Message is undefined');
//       }
//     }



//   function splitIntoChunks(text: string, maxChunkSize: number): string[] {
//     const chunks = [];
//     let start = 0;
    
//     while (start < text.length) {
//       const end = Math.min(start + maxChunkSize, text.length);
//       chunks.push(text.slice(start, end));
//       start = end;
//     }

//     return chunks
//   }
// }
