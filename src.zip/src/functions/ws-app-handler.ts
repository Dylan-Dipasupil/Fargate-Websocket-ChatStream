
import { getOrThrowIfEmpty } from '@src/utils';
import { SlackEventsEnv } from '@functions/slack-event-handler';
import { Secret, openModal, createModal  } from '@src/helpers/slack/slack-helpers';
import { SessionManagerEnv, getSessionCreds, startSession } from '@helpers/idc/session-helpers';
import { getMarkdownBlock,  getMarkdownBlocks, validateSlackRequest } from '@helpers/slack/slack-helpers';
import { chatDependencies, deleteChannelMetadata, getChannelKey } from '@helpers/chat';
import { getSignInBlocks } from '@helpers/amazon-q/amazon-q-helpers';
import { SLACK_ACTION } from '@src/helpers/slack/slack-helpers';
import { ChatSyncCommandOutput } from '@aws-sdk/client-qbusiness';
import { getMessageMetadata } from '@helpers/chat';
import { Credentials } from 'aws-sdk';
import { isEmpty } from '@src/utils';


import { getSlackSecret } from '@helpers/slack/slack-helpers'

import { 
  App, 
  LogLevel, 
  KnownEventFromType, 
  SlashCommand, 
  DialogSubmitAction, 
  WorkflowStepEdit, 
  BlockElementAction, 
  InteractiveAction,
  SlackAction } from '@slack/bolt';

import { WebClient } from '@slack/web-api';

const processSlackEventsEnv = (env: NodeJS.ProcessEnv) => ({
  REGION: getOrThrowIfEmpty(env.AWS_REGION ?? env.AWS_DEFAULT_REGION),
  SLACK_SECRET_NAME: getOrThrowIfEmpty(env.SLACK_SECRET_NAME),
  AMAZON_Q_APP_ID: getOrThrowIfEmpty(env.AMAZON_Q_APP_ID),
  AMAZON_Q_REGION: getOrThrowIfEmpty(env.AMAZON_Q_REGION),
  CONTEXT_DAYS_TO_LIVE: getOrThrowIfEmpty(env.CONTEXT_DAYS_TO_LIVE),
  CACHE_TABLE_NAME: getOrThrowIfEmpty(env.CACHE_TABLE_NAME),
  MESSAGE_METADATA_TABLE_NAME: getOrThrowIfEmpty(env.MESSAGE_METADATA_TABLE_NAME),
  OIDC_STATE_TABLE_NAME: getOrThrowIfEmpty(env.OIDC_STATE_TABLE_NAME),
  IAM_SESSION_TABLE_NAME: getOrThrowIfEmpty(env.IAM_SESSION_CREDENTIALS_TABLE_NAME),
  OIDC_IDP_NAME: getOrThrowIfEmpty(env.OIDC_IDP_NAME),
  OIDC_ISSUER_URL: getOrThrowIfEmpty(env.OIDC_ISSUER_URL),
  OIDC_CLIENT_ID: getOrThrowIfEmpty(env.OIDC_CLIENT_ID),
  OIDC_CLIENT_SECRET_NAME: getOrThrowIfEmpty(env.OIDC_CLIENT_SECRET_NAME),
  OIDC_REDIRECT_URL: getOrThrowIfEmpty(env.OIDC_REDIRECT_URL),
  KMS_KEY_ARN: getOrThrowIfEmpty(env.KEY_ARN),
  Q_USER_API_ROLE_ARN: getOrThrowIfEmpty(env.Q_USER_API_ROLE_ARN),
  GATEWAY_IDC_APP_ARN: getOrThrowIfEmpty(env.GATEWAY_IDC_APP_ARN)
});

const dependencies = {
  ...chatDependencies,
  validateSlackRequest,
  getSessionCreds,
  startSession
}

export const handler = async () => {
  try {
    const slackEventsEnv = processSlackEventsEnv(process.env);
    const secret = await getSlackSecret(slackEventsEnv);
    const wsApp = new App({
        token: secret.SlackBotUserOAuthToken,
        signingSecret: secret.SlackSigningSecret,
        socketMode: true,
        appToken: secret.SlackAppToken,
        logLevel: LogLevel.DEBUG,
  });

    wsApp.message(async ({ message }) => {
      try {
        await handleMessage(message, secret, wsApp)
      } catch (error) {
        console.error('Error responding to message:', error);
      }
    });

    wsApp.command('/new_conversation', async ({ command, ack }) => {
      try {
        await ack();
        await handleCommand(secret, wsApp, slackEventsEnv, command);
      } catch (error) {
        console.error('Error responding to command:', error);
      }
    })

    wsApp.action('', async ({ ack, action }) => {
      try {
        await ack();
       if (action.type == 'button') {
        console.log("Printing the button stuff")
        console.log(action.value)
        console.log(JSON.stringify(action.value))
       }
      } catch (error) {
        console.error('Error responding to interaction:', error);
      }
    })
  

    await wsApp.start();
    console.log('Bolt app is running!');

  } catch (error) {
    console.error('Error starting Bolt app:', error);
  }
};

const handleMessage = async (message: KnownEventFromType<"message">, secret: Secret, wsApp: App) => {
  console.log('Received message:', message);
  const result = await wsApp.client.chat.postMessage({
    token: secret.SlackBotUserOAuthToken,
    text: 'Handle Message Response',
    channel: message.channel
  });
}

const handleCommand = async (secret: Secret, wsApp: App, slackEventsEnv: SlackEventsEnv, command: SlashCommand) => {
  const sessionManagerEnv: SessionManagerEnv = {
    oidcStateTableName: slackEventsEnv.OIDC_STATE_TABLE_NAME,
    iamSessionCredentialsTableName: slackEventsEnv.IAM_SESSION_TABLE_NAME,
    oidcIdPName: slackEventsEnv.OIDC_IDP_NAME,
    oidcClientId: slackEventsEnv.OIDC_CLIENT_ID,
    oidcClientSecretName: slackEventsEnv.OIDC_CLIENT_SECRET_NAME,
    oidcIssuerUrl: slackEventsEnv.OIDC_ISSUER_URL,
    oidcRedirectUrl: slackEventsEnv.OIDC_REDIRECT_URL,
    kmsKeyArn: slackEventsEnv.KMS_KEY_ARN,
    region: slackEventsEnv.AMAZON_Q_REGION,
    qUserAPIRoleArn: slackEventsEnv.Q_USER_API_ROLE_ARN,
    gatewayIdCAppArn: slackEventsEnv.GATEWAY_IDC_APP_ARN
  };
  try {
    await dependencies.getSessionCreds(sessionManagerEnv, command.user_id);
  } catch (error) {
    // call sessionManager.startSession() to start a new session
    console.error(`Failed to get session: ${error}`);
    const authorizationURL = await dependencies.startSession(sessionManagerEnv, command.user_id);

    // post a message to channel to return a slack button for authorization url
    await dependencies.sendSlackMessage(
      slackEventsEnv,
      command.user_id,
      `<@${command.user_id}>, please sign in through the Amazon Q bot app to continue.`,
      getSignInBlocks(authorizationURL)
    );

  }
  let commandStatus;
  if (command.command.startsWith('/new_conv')) {
    const channelKey = getChannelKey('message', command.team_id, command.channel_id, 'n/a');
    console.debug(`Slash command: ${command.command} - deleting channel metadata for '${channelKey}'`);
    await deleteChannelMetadata(channelKey, dependencies, slackEventsEnv);
    await dependencies.sendSlackMessage(
      slackEventsEnv,
      command.channel_id,
      `Starting New Conversation`,
      [getMarkdownBlock(`_*Starting New Conversation*_`)]
    );
    commandStatus = 'OK';
  } else {
    console.error(`ERROR - unsupported slash command: ${command.command}`);
    commandStatus = 'Unsupported';
  }}


handler()